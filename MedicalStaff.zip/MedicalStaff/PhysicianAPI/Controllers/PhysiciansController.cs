﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhysicianAPI.Models;

namespace PhysicianAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PhysiciansController : ControllerBase
    {
        private readonly ChdbContext _context;

        public PhysiciansController(ChdbContext context)
        {
            _context = context;
        }

        // GET: api/Physicians
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Physician>>> GetPhysicians()
        {
          if (_context.Physicians == null)
          {
              return NotFound();
          }
            return await _context.Physicians.ToListAsync();
        }

        // GET: api/Physicians/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Physician>> GetPhysician(int id)
        {
          if (_context.Physicians == null)
          {
              return NotFound();
          }
            var physician = await _context.Physicians.FindAsync(id);

            if (physician == null)
            {
                return NotFound();
            }

            return physician;
        }

        // PUT: api/Physicians/5
        
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPhysician(int id, Physician physician)
        {
            if (id != physician.PhysicianId)
            {
                return BadRequest();
            }

            _context.Entry(physician).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PhysicianExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Physicians
       
        [HttpPost]
        public async Task<ActionResult<Physician>> PostPhysician(Physician physician)
        {
          if (_context.Physicians == null)
          {
              return Problem("Entity set 'ChdbContext.Physicians'  is null.");
          }
            _context.Physicians.Add(physician);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPhysician", new { id = physician.PhysicianId }, physician);
        }

        // DELETE: api/Physicians/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePhysician(int id)
        {
            if (_context.Physicians == null)
            {
                return NotFound();
            }
            var physician = await _context.Physicians.FindAsync(id);
            if (physician == null)
            {
                return NotFound();
            }

            _context.Physicians.Remove(physician);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PhysicianExists(int id)
        {
            return (_context.Physicians?.Any(e => e.PhysicianId == id)).GetValueOrDefault();
        }
    }
}
